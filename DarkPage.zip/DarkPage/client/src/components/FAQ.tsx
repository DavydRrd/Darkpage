import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Preciso de equipamento?",
    answer: "Não, todos os treinos usam apenas o peso corporal. Você pode fazer em casa sem nenhum equipamento."
  },
  {
    question: "Quanto tempo por dia?",
    answer: "15-20 minutos de treino por dia. Curto e intenso para caber na sua rotina."
  },
  {
    question: "A dieta é muito restritiva?",
    answer: "Não. Usamos alimentos comuns e práticos. Nada de receitas complicadas ou ingredientes caros."
  },
  {
    question: "Funciona para iniciantes?",
    answer: "Sim! O plano é adaptável para todos os níveis. Temos variações de exercícios para iniciantes."
  },
  {
    question: "Como recebo o material?",
    answer: "Imediatamente após a compra, você recebe tudo por email e WhatsApp. Acesso instantâneo."
  },
  {
    question: "Posso cancelar e pedir reembolso?",
    answer: "Sim, garantia total de 7 dias. Se não gostar, devolvemos 100% do valor sem perguntas."
  }
];

export default function FAQ() {
  return (
    <section className="py-16 border-t" id="faq">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl text-foreground mb-12 text-center">
          PERGUNTAS FREQUENTES
        </h2>
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-card border rounded-md px-6"
                data-testid={`faq-${index}`}
              >
                <AccordionTrigger className="text-foreground hover:text-foreground/80 text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
