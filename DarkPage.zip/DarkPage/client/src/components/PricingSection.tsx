import { Button } from "@/components/ui/button";
import { Book, Utensils, Dumbbell } from 'lucide-react';

interface PricingSectionProps {
  onCheckoutBase?: () => void;
  onCheckoutBonus?: () => void;
  onCheckoutBump1?: () => void;
  onCheckoutBump2?: () => void;
  onCheckoutBump3?: () => void;
}

export default function PricingSection({ 
  onCheckoutBase, 
  onCheckoutBonus,
  onCheckoutBump1,
  onCheckoutBump2,
  onCheckoutBump3
}: PricingSectionProps) {
  return (
    <section className="py-16 border-t">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl text-foreground mb-12 text-center">
          ESCOLHA SUA OFERTA
        </h2>
        
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Ofertas Principais */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Oferta Base */}
            <div className="bg-card border rounded-md p-6 space-y-4">
              <h3 className="font-semibold text-xl text-foreground">Plano Base</h3>
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold text-foreground">R$ 8,99</span>
                <span className="text-lg text-muted-foreground line-through">R$ 27,99</span>
              </div>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>✓ Plano completo de 7 dias</li>
                <li>✓ Treinos diários em vídeo</li>
                <li>✓ Cardápio simplificado</li>
                <li>✓ Garantia de 7 dias</li>
              </ul>
              <Button 
                size="lg"
                className="w-full bg-[#cf1f1f] hover:bg-[#b01a1a] text-white font-semibold h-auto py-4"
                onClick={onCheckoutBase}
                data-testid="button-checkout-base-full"
              >
                COMPRAR AGORA — R$ 8,99
              </Button>
            </div>

            {/* Oferta com Bônus */}
            <div className="bg-card border-2 border-[#cf1f1f]/30 rounded-md p-6 space-y-4 relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <span className="bg-[#cf1f1f] text-white text-xs font-semibold px-4 py-1 rounded-full">
                  MAIS POPULAR
                </span>
              </div>
              <h3 className="font-semibold text-xl text-foreground">Plano + Bônus</h3>
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold text-foreground">R$ 14,99</span>
                <span className="text-lg text-muted-foreground line-through">R$ 47,00</span>
              </div>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>✓ Tudo do Plano Base</li>
                <li>✓ Guia de receitas fit exclusivo</li>
                <li>✓ Plano de 30 dias estendido</li>
                <li>✓ Acesso prioritário</li>
              </ul>
              <Button 
                size="lg"
                className="w-full bg-[#cf1f1f] hover:bg-[#b01a1a] text-white font-semibold h-auto py-4"
                onClick={onCheckoutBonus}
                data-testid="button-checkout-bonus-full"
              >
                COMPRAR COM BÔNUS — R$ 14,99
              </Button>
            </div>
          </div>

          {/* Order Bumps Separados */}
          <div className="space-y-4">
            <h3 className="font-semibold text-foreground text-lg text-center">Ou potencialize ainda mais:</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Bump 1 */}
              <div className="bg-card border rounded-md p-6 text-center space-y-4">
                <Book className="w-8 h-8 text-[#cf1f1f] mx-auto" />
                <div>
                  <h4 className="font-semibold text-foreground mb-2">Guia de Receitas Fit</h4>
                  <p className="text-sm text-muted-foreground mb-3">50+ receitas práticas e saudáveis</p>
                  <p className="text-2xl font-bold text-foreground mb-4">R$ 5,99</p>
                </div>
                <Button 
                  size="lg"
                  variant="outline"
                  className="w-full border-[#cf1f1f] text-[#cf1f1f] hover:bg-[#cf1f1f] hover:text-white"
                  onClick={onCheckoutBump1}
                  data-testid="button-bump-1"
                >
                  COMPRAR SEPARADO
                </Button>
              </div>

              {/* Bump 2 */}
              <div className="bg-card border rounded-md p-6 text-center space-y-4">
                <Utensils className="w-8 h-8 text-[#cf1f1f] mx-auto" />
                <div>
                  <h4 className="font-semibold text-foreground mb-2">Plano de Refeições Premium</h4>
                  <p className="text-sm text-muted-foreground mb-3">Cardápio detalhado para 30 dias</p>
                  <p className="text-2xl font-bold text-foreground mb-4">R$ 6,99</p>
                </div>
                <Button 
                  size="lg"
                  variant="outline"
                  className="w-full border-[#cf1f1f] text-[#cf1f1f] hover:bg-[#cf1f1f] hover:text-white"
                  onClick={onCheckoutBump2}
                  data-testid="button-bump-2"
                >
                  COMPRAR SEPARADO
                </Button>
              </div>

              {/* Bump 3 */}
              <div className="bg-card border rounded-md p-6 text-center space-y-4">
                <Dumbbell className="w-8 h-8 text-[#cf1f1f] mx-auto" />
                <div>
                  <h4 className="font-semibold text-foreground mb-2">Ideias de Treinos em Casa</h4>
                  <p className="text-sm text-muted-foreground mb-3">Variações e progressões de exercícios</p>
                  <p className="text-2xl font-bold text-foreground mb-4">R$ 8,99</p>
                </div>
                <Button 
                  size="lg"
                  variant="outline"
                  className="w-full border-[#cf1f1f] text-[#cf1f1f] hover:bg-[#cf1f1f] hover:text-white"
                  onClick={onCheckoutBump3}
                  data-testid="button-bump-3"
                >
                  COMPRAR SEPARADO
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
