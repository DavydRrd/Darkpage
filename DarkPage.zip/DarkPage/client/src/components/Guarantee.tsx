import { ShieldCheck } from 'lucide-react';

export default function Guarantee() {
  return (
    <section className="py-16 border-t" id="garantia">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-[#cf1f1f]/10 rounded-full">
            <ShieldCheck className="w-12 h-12 text-[#cf1f1f]" />
          </div>
          <h2 className="font-heading text-3xl md:text-4xl text-foreground">
            GARANTIA 7 DIAS — DEVOLUÇÃO TOTAL
          </h2>
          <p className="text-lg text-foreground/80">
            Se não ficar satisfeito nos primeiros 7 dias, devolvemos 100% do valor.
          </p>
          <div className="bg-card border rounded-md p-6 text-left">
            <h3 className="font-semibold text-foreground mb-3">Política de Reembolso</h3>
            <p className="text-muted-foreground mb-4">
              Garantia de 7 dias: reembolso total se não ficar satisfeito. Solicite via email ou WhatsApp em até 7 dias da compra.
            </p>
            <a href="#" className="text-[#cf1f1f] hover:underline text-sm">
              Ver termos completos →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
