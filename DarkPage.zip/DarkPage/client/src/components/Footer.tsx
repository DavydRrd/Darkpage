import { CreditCard, ShieldCheck, Lock } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t bg-muted/30 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="font-semibold text-foreground mb-4">Plano Choque 7D</h3>
            <p className="text-sm text-muted-foreground">
              Emagrecimento visível em 7 dias. Método comprovado e garantido.
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-4">Links</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-foreground">Política de Privacidade</a></li>
              <li><a href="#" className="hover:text-foreground">Termos de Uso</a></li>
              <li><a href="#" className="hover:text-foreground">Contato</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-4">Pagamento Seguro</h3>
            <div className="flex items-center gap-4 mb-4">
              <CreditCard className="w-8 h-8 text-muted-foreground" />
              <ShieldCheck className="w-8 h-8 text-muted-foreground" />
              <Lock className="w-8 h-8 text-muted-foreground" />
            </div>
          </div>
        </div>
        <div className="border-t pt-8 text-center text-sm text-muted-foreground">
          <p className="mb-2">
            <strong>Aviso Legal:</strong> Resultados variam. Não substitui orientação médica. Consulte um profissional se você tem condição pré-existente (pressão alta, problemas cardíacos, gravidez).
          </p>
          <p>© 2024 Plano Choque 7D. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
