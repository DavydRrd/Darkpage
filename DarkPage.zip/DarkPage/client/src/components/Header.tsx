export default function Header() {
  return (
    <header className="border-b bg-background">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="text-2xl font-heading text-foreground">
            CHOQUE 7D
          </div>
        </div>
        <div className="flex items-center gap-4 md:gap-6">
          <a 
            href="#faq" 
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-faq"
          >
            FAQs
          </a>
          <a 
            href="#garantia" 
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-policy"
          >
            Política
          </a>
        </div>
      </div>
    </header>
  );
}
