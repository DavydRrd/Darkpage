import Guarantee from '../Guarantee';

export default function GuaranteeExample() {
  return (
    <div className="bg-background">
      <Guarantee />
    </div>
  );
}
