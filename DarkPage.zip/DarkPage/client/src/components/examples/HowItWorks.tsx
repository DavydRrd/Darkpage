import HowItWorks from '../HowItWorks';

export default function HowItWorksExample() {
  return (
    <div className="bg-background">
      <HowItWorks />
    </div>
  );
}
