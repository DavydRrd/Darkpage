import FAQ from '../FAQ';

export default function FAQExample() {
  return (
    <div className="bg-background">
      <FAQ />
    </div>
  );
}
