import PricingSection from '../PricingSection';

export default function PricingSectionExample() {
  return (
    <div className="bg-background">
      <PricingSection 
        onCheckoutBase={() => console.log('Checkout base clicked')}
        onCheckoutBonus={() => console.log('Checkout bonus clicked')}
        onCheckoutBump1={() => console.log('Bump 1 clicked')}
        onCheckoutBump2={() => console.log('Bump 2 clicked')}
        onCheckoutBump3={() => console.log('Bump 3 clicked')}
      />
    </div>
  );
}
