import UrgencyBanner from '../UrgencyBanner';

export default function UrgencyBannerExample() {
  return (
    <div className="bg-background">
      <UrgencyBanner />
    </div>
  );
}
