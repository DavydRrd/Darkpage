import Testimonials from '../Testimonials';

export default function TestimonialsExample() {
  return (
    <div className="bg-background">
      <Testimonials />
    </div>
  );
}
