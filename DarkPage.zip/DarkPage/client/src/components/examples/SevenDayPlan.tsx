import SevenDayPlan from '../SevenDayPlan';

export default function SevenDayPlanExample() {
  return (
    <div className="bg-background">
      <SevenDayPlan />
    </div>
  );
}
