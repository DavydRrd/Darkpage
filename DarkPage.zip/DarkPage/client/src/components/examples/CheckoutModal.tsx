import { useState } from 'react';
import CheckoutModal from '../CheckoutModal';
import { Button } from '@/components/ui/button';

export default function CheckoutModalExample() {
  const [open, setOpen] = useState(false);
  
  return (
    <div className="bg-background p-8">
      <Button onClick={() => setOpen(true)}>Open Checkout Modal</Button>
      <CheckoutModal 
        open={open}
        onOpenChange={setOpen}
        productType="bonus"
      />
    </div>
  );
}
