import PricingBox from '../PricingBox';

export default function PricingBoxExample() {
  return (
    <div className="bg-background p-8">
      <div className="max-w-md">
        <PricingBox 
          onCheckoutBase={() => console.log('Checkout base clicked')}
          onCheckoutBonus={() => console.log('Checkout bonus clicked')}
        />
      </div>
    </div>
  );
}
