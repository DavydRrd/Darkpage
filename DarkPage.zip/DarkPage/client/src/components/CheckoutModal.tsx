import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ShieldCheck } from 'lucide-react';

interface CheckoutModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  productType: 'base' | 'bonus' | 'bump1' | 'bump2' | 'bump3';
}

const products = {
  base: { 
    title: 'Plano Choque 7D - Base', 
    price: 8.99,
    paymentLink: 'https://pay.cakto.com.br/a6jaeu7_608861'
  },
  bonus: { 
    title: 'Plano Choque 7D - Com Bônus', 
    price: 14.99,
    paymentLink: 'https://pay.cakto.com.br/gu4dzkk_608921'
  },
  bump1: { 
    title: 'Guia de Receitas Fit', 
    price: 5.99,
    paymentLink: 'https://pay.cakto.com.br/smtoq8g_608895'
  },
  bump2: { 
    title: 'Plano de Refeições Premium', 
    price: 6.99,
    paymentLink: 'https://pay.cakto.com.br/3feydog_608902'
  },
  bump3: { 
    title: 'Ideias de Treinos em Casa', 
    price: 8.99,
    paymentLink: 'https://pay.cakto.com.br/33pdmat_608903'
  },
};

export default function CheckoutModal({ open, onOpenChange, productType }: CheckoutModalProps) {
  const product = products[productType];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    window.location.href = product.paymentLink;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-background border text-foreground max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-heading">FINALIZAR COMPRA</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="space-y-3">
            <h3 className="font-semibold">Resumo do Pedido</h3>
            <div className="bg-muted rounded-md p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{product.title}</span>
                <span className="text-foreground">R$ {product.price.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold pt-2 border-t">
                <span>TOTAL</span>
                <span data-testid="text-modal-total">R$ {product.price.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Nome Completo</Label>
              <Input 
                id="name" 
                placeholder="Seu nome" 
                className="bg-background"
                data-testid="input-name"
                required
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="seu@email.com" 
                className="bg-background"
                data-testid="input-email"
                required
              />
            </div>
            <div>
              <Label htmlFor="phone">Telefone</Label>
              <Input 
                id="phone" 
                type="tel" 
                placeholder="(11) 99999-9999" 
                className="bg-background"
                data-testid="input-phone"
                required
              />
            </div>

            <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted rounded-md p-3">
              <ShieldCheck className="w-4 h-4 text-[#cf1f1f]" />
              <span>Pagamento 100% seguro. Garantia de 7 dias.</span>
            </div>

            <Button 
              type="submit"
              size="lg"
              className="w-full bg-[#cf1f1f] hover:bg-[#b01a1a] text-white font-semibold text-lg h-auto py-4"
              data-testid="button-pay"
            >
              PAGAR — R$ {product.price.toFixed(2)}
            </Button>
          </form>

          <p className="text-xs text-muted-foreground text-center">
            Ao finalizar a compra, você concorda com nossos Termos de Uso e Política de Privacidade.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
