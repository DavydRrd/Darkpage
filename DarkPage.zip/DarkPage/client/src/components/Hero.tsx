import { Button } from "@/components/ui/button";

interface HeroProps {
  onBuyClick?: () => void;
}

export default function Hero({ onBuyClick }: HeroProps) {
  return (
    <div className="py-12 md:py-16 lg:py-20">
      <div className="space-y-6">
        <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl xl:text-7xl text-foreground leading-tight tracking-tight">
          EMAGREÇA EM 7 DIAS — PLANO CHOQUE 7D
        </h1>
        <p className="text-lg md:text-xl text-foreground/80 max-w-xl">
          Resultado visível. Sem enrolação. Teste de 7 dias.
        </p>
        <Button 
          size="lg"
          className="bg-[#cf1f1f] hover:bg-[#b01a1a] text-white font-semibold text-lg px-8 py-6 h-auto"
          onClick={onBuyClick}
          data-testid="button-buy-now"
          aria-label="Comprar agora por R$8,99"
        >
          COMPRAR AGORA — R$8,99
        </Button>
      </div>
    </div>
  );
}
