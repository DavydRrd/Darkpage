import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Shield } from 'lucide-react';

interface PricingBoxProps {
  onCheckoutBase?: () => void;
  onCheckoutBonus?: () => void;
}

export default function PricingBox({ onCheckoutBase, onCheckoutBonus }: PricingBoxProps) {
  const [timeLeft, setTimeLeft] = useState({ minutes: 30, seconds: 0 });

  useEffect(() => {
    const getDeadline = () => {
      const key = 'promo_deadline_v1';
      let deadline = localStorage.getItem(key);
      if (!deadline) {
        const now = Date.now();
        deadline = String(now + 30 * 60 * 1000);
        localStorage.setItem(key, deadline);
      }
      return parseInt(deadline, 10);
    };

    const deadline = getDeadline();
    const interval = setInterval(() => {
      const now = Date.now();
      const diff = deadline - now;
      if (diff <= 0) {
        clearInterval(interval);
        localStorage.removeItem('promo_deadline_v1');
        setTimeLeft({ minutes: 0, seconds: 0 });
        return;
      }
      const minutes = Math.floor((diff / 1000 / 60) % 60);
      const seconds = Math.floor((diff / 1000) % 60);
      setTimeLeft({ minutes, seconds });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-4">
      {/* Oferta Base */}
      <div className="bg-card border rounded-md p-6 space-y-4">
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground uppercase tracking-wide">Oferta Relâmpago</p>
          <div className="flex items-baseline gap-3">
            <span className="text-3xl font-bold text-foreground">R$ 8,99</span>
            <span className="text-lg text-muted-foreground line-through">R$ 27,99</span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm text-foreground">
          <Shield className="w-4 h-4" />
          <span>Garantia 7 dias</span>
        </div>

        <Button 
          size="lg"
          className="w-full bg-[#cf1f1f] hover:bg-[#b01a1a] text-white font-semibold text-lg h-auto py-4"
          onClick={onCheckoutBase}
          data-testid="button-checkout-base"
          aria-label="Finalizar compra plano base por R$8,99"
        >
          COMPRAR PLANO BASE — R$ 8,99
        </Button>
      </div>

      {/* Oferta com Bônus */}
      <div className="bg-card border-2 border-[#cf1f1f]/30 rounded-md p-6 space-y-4">
        <div className="inline-block bg-[#cf1f1f] text-white text-xs font-semibold px-3 py-1 rounded-full mb-2">
          MAIS POPULAR
        </div>
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground uppercase tracking-wide">Com Bônus Exclusivos</p>
          <div className="flex items-baseline gap-3">
            <span className="text-3xl font-bold text-foreground">R$ 14,99</span>
            <span className="text-lg text-muted-foreground line-through">R$ 47,00</span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm text-foreground">
          <Shield className="w-4 h-4" />
          <span>Garantia 7 dias + Bônus</span>
        </div>

        <Button 
          size="lg"
          className="w-full bg-[#cf1f1f] hover:bg-[#b01a1a] text-white font-semibold text-lg h-auto py-4"
          onClick={onCheckoutBonus}
          data-testid="button-checkout-bonus"
          aria-label="Finalizar compra com bônus por R$14,99"
        >
          COMPRAR COM BÔNUS — R$ 14,99
        </Button>
      </div>

      {/* Countdown */}
      <div className="space-y-2">
        <p className="text-sm text-muted-foreground text-center">Promoção termina em:</p>
        <div className="bg-card border rounded-md px-4 py-3 text-center" data-testid="text-countdown">
          <span className="text-3xl font-heading text-[#cf1f1f]">
            {String(timeLeft.minutes).padStart(2, '0')}:{String(timeLeft.seconds).padStart(2, '0')}
          </span>
        </div>
      </div>
    </div>
  );
}
