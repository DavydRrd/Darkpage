import { useState, useEffect } from 'react';
import { AlertCircle } from 'lucide-react';

export default function UrgencyBanner() {
  const [timeLeft, setTimeLeft] = useState({ minutes: 30, seconds: 0 });

  useEffect(() => {
    const getDeadline = () => {
      const key = 'promo_deadline_v1';
      let deadline = localStorage.getItem(key);
      if (!deadline) {
        const now = Date.now();
        deadline = String(now + 30 * 60 * 1000);
        localStorage.setItem(key, deadline);
      }
      return parseInt(deadline, 10);
    };

    const deadline = getDeadline();
    const interval = setInterval(() => {
      const now = Date.now();
      const diff = deadline - now;
      if (diff <= 0) {
        clearInterval(interval);
        localStorage.removeItem('promo_deadline_v1');
        setTimeLeft({ minutes: 0, seconds: 0 });
        return;
      }
      const minutes = Math.floor((diff / 1000 / 60) % 60);
      const seconds = Math.floor((diff / 1000) % 60);
      setTimeLeft({ minutes, seconds });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-12 border-t">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto bg-[#cf1f1f]/5 border-2 border-[#cf1f1f] rounded-md p-8 text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-[#cf1f1f] rounded-full mb-2">
            <AlertCircle className="w-8 h-8 text-white" />
          </div>
          <h3 className="font-heading text-2xl md:text-3xl text-foreground">
            APROVEITE A PROMOÇÃO
          </h3>
          <p className="text-foreground/80">
            Preço normal R$27,99 — <strong>HOJE por R$8,99</strong>
            <br />
            Oferta com bônus: <strong>R$14,99</strong> <span className="text-muted-foreground">(antes R$47,00)</span>
          </p>
          <div className="inline-block bg-card border rounded-md px-6 py-3">
            <p className="text-sm text-muted-foreground mb-1">RESTAM:</p>
            <p className="text-3xl font-heading text-[#cf1f1f]" data-testid="text-urgency-countdown">
              {String(timeLeft.minutes).padStart(2, '0')}:{String(timeLeft.seconds).padStart(2, '0')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
