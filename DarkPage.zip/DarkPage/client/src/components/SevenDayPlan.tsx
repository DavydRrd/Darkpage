import { Button } from "@/components/ui/button";
import { Zap, Dumbbell, Heart, Flame, Target, TrendingUp, Trophy } from 'lucide-react';

const days = [
  { day: 1, icon: Zap, text: "Ativação metabólica inicial" },
  { day: 2, icon: Dumbbell, text: "Treino intensivo + hidratação" },
  { day: 3, icon: Heart, text: "Cardio estratégico" },
  { day: 4, icon: Flame, text: "Queima acelerada de gordura" },
  { day: 5, icon: Target, text: "Foco em definição" },
  { day: 6, icon: TrendingUp, text: "Potencialização de resultados" },
  { day: 7, icon: Trophy, text: "Consolidação e medição" },
];

export default function SevenDayPlan() {
  return (
    <section className="py-16 border-t">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl text-foreground mb-12 text-center">
          O PLANO EM 7 DIAS
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {days.map(({ day, icon: Icon, text }) => (
            <div key={day} className="flex items-start gap-4 p-4 bg-card border rounded-md">
              <div className="bg-[#cf1f1f] rounded-md p-3 shrink-0">
                <Icon className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="font-semibold text-foreground mb-1">Dia {day}</div>
                <p className="text-sm text-muted-foreground">{text}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center">
          <Button 
            variant="outline" 
            data-testid="button-view-roadmap"
          >
            VER O ROTEIRO COMPLETO
          </Button>
        </div>
      </div>
    </section>
  );
}
