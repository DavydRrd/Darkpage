import { Clock, UtensilsCrossed, Sparkles } from 'lucide-react';

const features = [
  {
    icon: Clock,
    title: "Treinos curtos e intensos",
    description: "15-20 minutos por dia de exercícios de alta eficiência. Sem equipamento necessário."
  },
  {
    icon: UtensilsCrossed,
    title: "Dieta prática 7 dias",
    description: "Cardápio simples e direto. Alimentos comuns do dia a dia, fácil de seguir."
  },
  {
    icon: Sparkles,
    title: "Recuperação estratégica",
    description: "Técnicas de descanso ativo e hidratação para maximizar resultados."
  }
];

export default function HowItWorks() {
  return (
    <section className="py-16 border-t">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl text-foreground mb-12 text-center">
          COMO FUNCIONA
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map(({ icon: Icon, title, description }) => (
            <div key={title} className="text-center space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-[#cf1f1f] rounded-md">
                <Icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold text-xl text-foreground">{title}</h3>
              <p className="text-muted-foreground">{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
