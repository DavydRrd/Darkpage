import avatar1 from '@assets/stock_images/fitness_testimonial__90939d21.jpg';
import avatar2 from '@assets/stock_images/fitness_testimonial__0a83b132.jpg';
import avatar3 from '@assets/stock_images/fitness_testimonial__c33621e8.jpg';
import avatar4 from '@assets/stock_images/fitness_testimonial__bd12f35a.jpg';
import avatar5 from '@assets/stock_images/fitness_testimonial__74668687.jpg';

const testimonials = [
  { name: "Maria, 28", text: "Vi diferença em 7 dias — mais energia e menos inchaço.", avatar: avatar1 },
  { name: "Lucas, 34", text: "Treinos curtos, resultado real. Recomendo.", avatar: avatar2 },
  { name: "Ana, 31", text: "Simples e direto. Surpreendente.", avatar: avatar3 },
  { name: "Felipe, 26", text: "Cumpri os 7 dias e senti cintura menor.", avatar: avatar4 },
  { name: "Joana, 39", text: "Rotina prática que deu resultado inicial.", avatar: avatar5 }
];

export default function Testimonials() {
  return (
    <section className="py-16 border-t">
      <div className="container mx-auto px-4">
        <h2 className="font-heading text-3xl md:text-4xl text-foreground mb-12 text-center">
          QUEM JÁ TESTOU
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index} 
              className="bg-card border rounded-md p-6"
              data-testid={`testimonial-${index}`}
            >
              <div className="flex items-start gap-4">
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="flex-1">
                  <p className="text-foreground mb-2">"{testimonial.text}"</p>
                  <p className="text-sm text-muted-foreground">— {testimonial.name}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
