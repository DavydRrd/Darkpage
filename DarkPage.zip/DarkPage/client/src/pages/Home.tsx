import { useState } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import PricingBox from '@/components/PricingBox';
import SevenDayPlan from '@/components/SevenDayPlan';
import HowItWorks from '@/components/HowItWorks';
import PricingSection from '@/components/PricingSection';
import Testimonials from '@/components/Testimonials';
import Guarantee from '@/components/Guarantee';
import FAQ from '@/components/FAQ';
import UrgencyBanner from '@/components/UrgencyBanner';
import Footer from '@/components/Footer';
import CheckoutModal from '@/components/CheckoutModal';

export default function Home() {
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<'base' | 'bonus' | 'bump1' | 'bump2' | 'bump3'>('base');

  const handleCheckout = (productType: 'base' | 'bonus' | 'bump1' | 'bump2' | 'bump3') => {
    setSelectedProduct(productType);
    setCheckoutOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        <div className="container mx-auto px-4">
          <div className="lg:grid lg:grid-cols-[1fr_400px] lg:gap-12 xl:gap-16">
            <div>
              <Hero onBuyClick={() => handleCheckout('base')} />
            </div>
            <div className="hidden lg:block">
              <div className="sticky top-4 pt-12">
                <PricingBox 
                  onCheckoutBase={() => handleCheckout('base')}
                  onCheckoutBonus={() => handleCheckout('bonus')}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="lg:hidden container mx-auto px-4 py-8">
          <PricingBox 
            onCheckoutBase={() => handleCheckout('base')}
            onCheckoutBonus={() => handleCheckout('bonus')}
          />
        </div>

        <SevenDayPlan />
        <HowItWorks />
        <PricingSection 
          onCheckoutBase={() => handleCheckout('base')}
          onCheckoutBonus={() => handleCheckout('bonus')}
          onCheckoutBump1={() => handleCheckout('bump1')}
          onCheckoutBump2={() => handleCheckout('bump2')}
          onCheckoutBump3={() => handleCheckout('bump3')}
        />
        <Testimonials />
        <Guarantee />
        <FAQ />
        <UrgencyBanner />
      </main>

      <Footer />

      <CheckoutModal 
        open={checkoutOpen}
        onOpenChange={setCheckoutOpen}
        productType={selectedProduct}
      />
    </div>
  );
}
