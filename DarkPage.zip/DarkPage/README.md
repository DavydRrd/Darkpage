# Plano Choque 7D - Landing Page

Landing page de vendas para o programa de emagrecimento Plano Choque 7D com design limpo e claro, ofertas separadas, produtos independentes, countdown timer e redirecionamento para Cakto.

## 🚀 Como Usar

1. Inicie o servidor:
```bash
npm run dev
```

2. Acesse: `http://localhost:5000`

## 🎨 Design

- **Tema**: Claro com background light (#fafafa) e CTAs vermelho sangue (#cf1f1f)
- **Tipografia**: Anton/Impact para títulos, Inter/Roboto para corpo
- **Layout**: Mobile-first responsivo com pricing box sticky no desktop

## 💰 Preços e Links de Pagamento

### Ofertas Principais
- **Plano Base**: R$ 8,99 → https://pay.cakto.com.br/a6jaeu7_608861
- **Plano + Bônus**: R$ 14,99 → https://pay.cakto.com.br/gu4dzkk_608921

### Order Bumps (Produtos Separados)
- **Guia de Receitas Fit**: R$ 5,99 → https://pay.cakto.com.br/smtoq8g_608895
- **Plano de Refeições Premium**: R$ 6,99 → https://pay.cakto.com.br/3feydog_608902
- **Ideias de Treinos em Casa**: R$ 8,99 → https://pay.cakto.com.br/33pdmat_608903

### Como Alterar Links ou Preços

Edite o arquivo `client/src/components/CheckoutModal.tsx`:

```typescript
const products = {
  base: { 
    title: 'Plano Choque 7D - Base', 
    price: 8.99,
    paymentLink: 'https://pay.cakto.com.br/a6jaeu7_608861'
  },
  bonus: { 
    title: 'Plano Choque 7D - Com Bônus', 
    price: 14.99,
    paymentLink: 'https://pay.cakto.com.br/gu4dzkk_608921'
  },
  // ... etc
};
```

## ⏱️ Timer de Promoção

O timer de 30 minutos é configurado automaticamente e persiste no localStorage. Para alterar a duração:

1. Abra `client/src/components/PricingBox.tsx` ou `client/src/components/UrgencyBanner.tsx`
2. Procure por: `deadline = String(now + 30 * 60 * 1000)`
3. Altere `30` para a quantidade de minutos desejada

## 👥 Como Substituir Depoimentos

Os depoimentos estão em `client/src/components/Testimonials.tsx`:

```typescript
const testimonials = [
  { 
    name: "Maria, 28", 
    text: "Vi diferença em 7 dias — mais energia e menos inchaço.", 
    avatar: avatar1 
  },
  // ... adicione ou edite mais depoimentos
];
```

### Substituir Fotos dos Depoimentos

1. Adicione suas fotos em `attached_assets/`
2. Importe no componente: `import minhaFoto from '@assets/minhaFoto.jpg'`
3. Use na propriedade `avatar`

## 🛒 Estrutura de Ofertas

### Ofertas Principais (2 cards separados)
- **Plano Base**: R$ 8,99 → redireciona para Cakto
- **Plano + Bônus**: R$ 14,99 → redireciona para Cakto

### Order Bumps (3 produtos independentes)
- **Guia de Receitas Fit**: R$ 5,99
- **Plano de Refeições Premium**: R$ 6,99
- **Ideias de Treinos em Casa**: R$ 8,99

Cada produto tem seu próprio botão "COMPRAR SEPARADO" que abre o modal de checkout específico.

## 🔄 Fluxo de Checkout

1. Usuário clica em "COMPRAR AGORA" ou "COMPRAR SEPARADO"
2. Abre modal de checkout com resumo do pedido
3. Usuário preenche nome, email e telefone
4. Ao clicar em "PAGAR", é redirecionado para o link da Cakto correspondente

## 📋 Estrutura do Projeto

```
client/src/
├── components/
│   ├── Header.tsx           # Cabeçalho com logo e links
│   ├── Hero.tsx             # Hero section principal
│   ├── PricingBox.tsx       # Box de pricing (sticky no desktop)
│   ├── SevenDayPlan.tsx     # Plano dos 7 dias
│   ├── HowItWorks.tsx       # Como funciona (3 cards)
│   ├── PricingSection.tsx   # Ofertas separadas + Order Bumps independentes
│   ├── Testimonials.tsx     # Depoimentos
│   ├── Guarantee.tsx        # Garantia de 7 dias
│   ├── FAQ.tsx              # Perguntas frequentes
│   ├── UrgencyBanner.tsx    # Banner de urgência com countdown
│   ├── Footer.tsx           # Rodapé
│   └── CheckoutModal.tsx    # Modal de checkout com redirecionamento
└── pages/
    └── Home.tsx             # Página principal
```

## 🎯 Funcionalidades

- ✅ Timer de 30 minutos persistente (localStorage)
- ✅ Ofertas separadas (Base e Bônus) com links independentes
- ✅ Order bumps como produtos independentes (não checkboxes)
- ✅ Modal de checkout com coleta de informações
- ✅ Redirecionamento automático para Cakto após preenchimento
- ✅ Layout sticky pricing box (desktop)
- ✅ Design claro e limpo
- ✅ Totalmente responsivo (mobile-first)
- ✅ Acessibilidade (aria-labels, semântica HTML)

## 📝 Notas

- **Checkout**: O modal coleta informações (nome, email, telefone) e redireciona para o link da Cakto
- **Links de Pagamento**: Todos configurados para a plataforma Cakto
- **Preços Atualizados**: Guia R$ 5,99, Plano Premium R$ 6,99, Treinos R$ 8,99
- **Analytics**: Adicionar Google Analytics ou Facebook Pixel para tracking
- **SEO**: Meta tags já configuradas no `index.html`
