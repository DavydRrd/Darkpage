# Design Guidelines - Landing Page Plano Choque 7D

## Visual Theme & Design System

**Color Palette:**
- Background: Light/Clean (#fafafa / #f5f5f5)
- Primary CTA: Blood red (#cf1f1f)
- Text: Dark gray/Black (#1a1a1a)
- Cards: White with subtle borders

**Typography:**
- Headings: Sans-condensed heavy (Impact/Anton)
- Body: Inter/Roboto
- High contrast throughout

**Spacing & Layout:**
- Mobile-first responsive design
- Desktop: Hero left, sticky pricing box right
- Consistent spacing using modern standards

## Core Layout Structure

### Header
- Clean logo positioned left
- Policy and FAQ links top right
- Minimal design with light background

### Hero Section (First Fold)
**Left Side:**
- H1: "EMAGREÇA EM 7 DIAS — PLANO CHOQUE 7D"
- Subheadline: "Resultado visível. Sem enrolação. Teste de 7 dias."
- Primary CTA: "COMPRAR AGORA — R$8,99" (red button)

**Right Side (Sticky Desktop):**
- Pricing box with dynamic calculations
- Flash offer: R$8,99 (strikethrough R$27,99)
- Bonus offer: R$14,99 (strikethrough R$47,00) - separate card
- Small guarantee badge: "Garantia 7 dias" with icon
- Large countdown timer: "Promoção termina em: 30:00"
- Checkout buttons for each offer

### Section: O Plano em 7 Dias
- 7 icons with one-line explanations (Day 1 → Day 7)
- Secondary CTA: "VER O ROTEIRO COMPLETO"

### Section: Como Funciona
- 3 cards: "Treinos curtos e intensos", "Dieta prática 7 dias", "Recuperação estratégica"
- Short text per card

### Section: Escolha Sua Oferta
- Two separate offer cards:
  - Plano Base: R$8,99 (was R$27,99)
  - Plano + Bônus: R$14,99 (was R$47,00) - marked as "MAIS POPULAR"
- 3 independent order bump products (not checkboxes):
  - Guia de Receitas Fit: R$3,99
  - Plano de Refeições Premium: R$4,99
  - Ideias de Treinos em Casa: R$2,99
- Each with its own "COMPRAR SEPARADO" button

### Section: Testemunhos
- Maximum 5 testimonials
- Circular small photo + name + 1-2 line text
- Use carousel if more than 5

### Section: Garantia e Segurança
- Large visual seal: "Garantia 7 dias — devolução total"
- Text: "Se não ficar satisfeito nos primeiros 7 dias, devolvemos 100% do valor"
- Short refund policy + link to full terms

### Section: FAQ
- 6 quick questions answered
- Example: "Preciso de equipamento?" → "Não, treinos usam peso corporal"

### Section: Countdown + Urgência
- Reinforce 30-minute timer
- Copy: "Preço normal R$27,99 — HOJE por R$8,99. Oferta com bônus: R$14,99 (antes R$47,00)"

### Footer
- Legal links, contact, privacy
- Payment icons (placeholders)
- Legal note: "Resultados variam. Consulte um profissional de saúde se tiver condição médica"

## Interactive Components

**Pricing Logic:**
- Base: R$8,99 (strikethrough R$27,99)
- With bonus: R$14,99 (strikethrough R$47,00)
- Order bumps are independent products with separate purchase
- Each product opens its own checkout modal

**30-Minute Timer:**
- Persistent via localStorage (key: 'promo_deadline_v1')
- Starts on first visit
- Maintains time on page reload
- On expiry: show "promo expirou" message

**Checkout Modal:**
- Summary: selected product and price
- Payment form (name, email, phone)
- Payment button with total

## Accessibility
- All buttons with aria-label
- Sufficient color contrast
- Semantic HTML structure (header/main/section/footer)

## Images
- Testimonial photos from stock images
- Circular testimonial photos

## Microcopy (Exact)
- "COMPRAR PLANO BASE — R$8,99"
- "COMPRAR COM BÔNUS — R$14,99"
- "COMPRAR SEPARADO" (for order bumps)
- "PAGAR — R$X,XX"
- "APROVEITE A PROMOÇÃO — RESTAM: [00:29:59]"
- "Garantia 7 dias — devolução total"
